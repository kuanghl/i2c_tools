
pcm "$@" &

echo "$!" > pcm.pid
